export interface ProfilePageProps {
  searchParams: {
    username?: string;
  };
}